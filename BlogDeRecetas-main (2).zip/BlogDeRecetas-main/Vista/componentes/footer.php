<!-- footer de la pagina -->
<footer class="footer">
    <div class="container">
        <div class="texto">
            <p><span><a style="color: white;" href="./Vista/about.php" >CodeLab:</a></span> Bootcamp Fullstack Junior</p>
            <p>All rights reserved © April <span>2022</span></p>
            <p></p>
        </div>
        <!-- links de redes sociales -->
        <div class="redes">
            <ul>
                <li><a style="margin:5px;" href="http://www.facebook.com/sharer.php?u=<?=$site_url?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                <li><a style="margin:5px;" href="https://twitter.com/share?url=<?=$site_url?>&amp;text=Recetas%20en%205min&amp;hashtags=RecetasEn5min" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                <li><a href="https://youtu.be/dQw4w9WgXcQ"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
            </ul>
        </div>
    </div>
</footer>
<!-- aca cierra el container -->
</div>
</body>
</html>