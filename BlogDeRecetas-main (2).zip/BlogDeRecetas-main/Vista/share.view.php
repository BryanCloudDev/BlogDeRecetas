<?php 
    // pass web-site url
    $site_url  = "https://github.com/BryanCloudDev/BlogDeRecetas";
    // post title
    $site_title  = "Recetas en 5min";
?>