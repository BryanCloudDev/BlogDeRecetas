<?php require('./Controlador/crl.resultados.php')?>
<?php require('./Vista/resultados.view.php')?>