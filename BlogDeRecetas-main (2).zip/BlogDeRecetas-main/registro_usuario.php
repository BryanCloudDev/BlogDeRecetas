<?php require('./Controlador/crl.registro.usuario.php')?>
<?php require('./Vista/registro.usuario.view.php')?>