<?php require('./Controlador/crl.index.php')?>
<?php require('./Vista/index.view.php')?>