<?php require('./Controlador/crl.receta.php')?>
<?php require('./Vista/receta.view.php')?>