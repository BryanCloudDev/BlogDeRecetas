<?php require('./Controlador/crl.registrar.receta.php')?>
<?php require('./Vista/registrar.receta.view.php')?>